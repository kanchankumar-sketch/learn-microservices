package in.reinventing.apigatway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiGatwayApplicationTests {

	@Test
	void contextLoads() {
	}

}
